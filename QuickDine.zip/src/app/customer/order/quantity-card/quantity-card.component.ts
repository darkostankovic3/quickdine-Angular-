import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quantity-card',
  templateUrl: './quantity-card.component.html',
  styleUrls: ['./quantity-card.component.scss']
})
export class QuantityCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
