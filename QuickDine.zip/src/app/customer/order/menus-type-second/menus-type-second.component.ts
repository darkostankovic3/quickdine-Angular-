import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menus-type-second',
  templateUrl: './menus-type-second.component.html',
  styleUrls: ['./menus-type-second.component.scss']
})
export class MenusTypeSecondComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
