import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kiosk-product-detail-note',
  templateUrl: './kiosk-product-detail-note.component.html',
  styleUrls: ['./kiosk-product-detail-note.component.scss']
})
export class KioskProductDetailNoteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
