import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kiosk-tenant-list',
  templateUrl: './kiosk-tenant-list.component.html',
  styleUrls: ['./kiosk-tenant-list.component.scss']
})
export class KioskTenantListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
