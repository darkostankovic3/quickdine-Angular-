import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kiosk-end',
  templateUrl: './kiosk-end.component.html',
  styleUrls: ['./kiosk-end.component.scss']
})
export class KioskEndComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
