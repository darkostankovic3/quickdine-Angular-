import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kiosk-search',
  templateUrl: './kiosk-search.component.html',
  styleUrls: ['./kiosk-search.component.scss']
})
export class KioskSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
