import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kiosk-cart',
  templateUrl: './kiosk-cart.component.html',
  styleUrls: ['./kiosk-cart.component.scss']
})
export class KioskCartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
