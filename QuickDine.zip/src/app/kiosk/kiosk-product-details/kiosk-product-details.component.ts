import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kiosk-product-details',
  templateUrl: './kiosk-product-details.component.html',
  styleUrls: ['./kiosk-product-details.component.scss']
})
export class KioskProductDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
