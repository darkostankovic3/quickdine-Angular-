import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kiosk-home',
  templateUrl: './kiosk-home.component.html',
  styleUrls: ['./kiosk-home.component.scss']
})
export class KioskHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
